<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container">
<a href="<?php echo e(route('customer')); ?>" class="btn btn-danger">Go To Customer</a>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Age</th>
      <th scope="col">Province</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($student->id); ?></th>
        <td><?php echo e($student->name); ?></td>
        <td><?php echo e($student->age); ?></td>
        <td><?php echo e($student->province); ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
</div>
</body>
</html><?php /**PATH C:\Users\koemsran.phon\Downloads\PNC\SECOND YEAR\term4\Laravel\C1 - Laravel Installation\Lesson 1\Laravel-Github\laravel-24C\resources\views/students/list.blade.php ENDPATH**/ ?>